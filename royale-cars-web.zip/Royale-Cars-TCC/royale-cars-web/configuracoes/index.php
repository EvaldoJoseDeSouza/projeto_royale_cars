<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../index.php');
    exit;
}

$usuarioId = $_SESSION['usuario_id'];

$mensagem = '';
$erro = '';


/*
|--------------------------------------------------------------------------
| ATUALIZAR DADOS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if ($nome === '' || $email === '') {

        $erro = 'Preencha o nome e o e-mail.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $erro = 'Digite um e-mail válido.';

    } else {

        // Verifica se outro usuário já utiliza o e-mail

        $sqlVerificar = "
            SELECT id
            FROM usuarios
            WHERE email = ?
            AND id != ?
        ";

        $stmtVerificar = $conexao->prepare($sqlVerificar);

        $stmtVerificar->bind_param(
            'si',
            $email,
            $usuarioId
        );

        $stmtVerificar->execute();

        $resultadoVerificar =
            $stmtVerificar->get_result();

        if ($resultadoVerificar->num_rows > 0) {

            $erro = 'Este e-mail já está sendo utilizado.';

        } else {

            $sqlAtualizar = "
                UPDATE usuarios
                SET nome = ?, email = ?
                WHERE id = ?
            ";

            $stmtAtualizar =
                $conexao->prepare($sqlAtualizar);

            $stmtAtualizar->bind_param(
                'ssi',
                $nome,
                $email,
                $usuarioId
            );

            if ($stmtAtualizar->execute()) {

                $_SESSION['usuario_nome'] = $nome;
                $_SESSION['usuario_email'] = $email;

                $mensagem =
                    'Dados atualizados com sucesso!';

            } else {

                $erro =
                    'Não foi possível atualizar os dados.';

            }

        }

    }

}


/*
|--------------------------------------------------------------------------
| BUSCAR DADOS DO USUÁRIO
|--------------------------------------------------------------------------
*/

$sqlUsuario = "
    SELECT id, nome, email
    FROM usuarios
    WHERE id = ?
";

$stmtUsuario =
    $conexao->prepare($sqlUsuario);

$stmtUsuario->bind_param(
    'i',
    $usuarioId
);

$stmtUsuario->execute();

$resultadoUsuario =
    $stmtUsuario->get_result();

$usuario =
    $resultadoUsuario->fetch_assoc();

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Configurações - Royale Cars
    </title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >

    <link
        rel="stylesheet"
        href="../css/dashboard.css"
    >

</head>

<body>

    <aside class="sidebar">

        <div class="logo">

            <h2>
                ROYALE
                <span>CARS</span>
            </h2>

        </div>

        <nav class="menu">

            <a href="../dashboard.php">
                Dashboard
            </a>

            <a href="../veiculos/index.php">
                Frota de Veículos
            </a>

            <a href="../clientes/index.php">
                Clientes
            </a>

            <a href="../locacoes/index.php">
                Locações
            </a>

            <a href="../financeiro/index.php">
                Financeiro
            </a>

            <a
                href="index.php"
                class="active"
            >
                Configurações
            </a>

            <a href="../logout.php">
                Sair
            </a>

        </nav>

    </aside>


    <main class="main">

        <header class="topbar">

            <div>

                <h1>Configurações</h1>

                <p class="topbar-subtitle">
                    Gerencie sua conta
                </p>

            </div>

            <div class="usuario-topo">

                <div class="usuario-avatar">

                    <?= strtoupper(
                        substr(
                            $_SESSION['usuario_nome'],
                            0,
                            1
                        )
                    ) ?>

                </div>

                <div>

                    <strong>
                        <?= htmlspecialchars(
                            $_SESSION['usuario_nome']
                        ) ?>
                    </strong>

                    <small>
                        Administrador
                    </small>

                </div>

            </div>

        </header>


        <section class="content">

            <div class="page-header">

                <div>

                    <h2>
                        Minha conta
                    </h2>

                    <p>
                        Atualize os dados do usuário
                        administrador.
                    </p>

                </div>

            </div>


            <?php if ($mensagem !== ''): ?>

                <div class="alert-success">

                    <?= htmlspecialchars($mensagem) ?>

                </div>

            <?php endif; ?>


            <?php if ($erro !== ''): ?>

                <div class="alert-error">

                    <?= htmlspecialchars($erro) ?>

                </div>

            <?php endif; ?>


            <div class="form-container">

                <form method="POST">

                    <div class="form-grid">

                        <div class="form-group">

                            <label for="nome">
                                Nome
                            </label>

                            <input
                                type="text"
                                id="nome"
                                name="nome"
                                value="<?= htmlspecialchars(
                                    $usuario['nome']
                                ) ?>"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label for="email">
                                E-mail
                            </label>

                            <input
                                type="email"
                                id="email"
                                name="email"
                                value="<?= htmlspecialchars(
                                    $usuario['email']
                                ) ?>"
                                required
                            >

                        </div>

                    </div>


                    <div class="form-actions">

                        <button
                            type="submit"
                            class="btn-primary"
                        >
                            Salvar alterações
                        </button>

                        <a
                            href="../dashboard.php"
                            class="btn-secondary"
                        >
                            Voltar
                        </a>

                    </div>

                </form>

            </div>

        </section>

    </main>

</body>

</html>