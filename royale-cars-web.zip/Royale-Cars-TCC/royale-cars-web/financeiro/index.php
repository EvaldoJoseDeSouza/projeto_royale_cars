<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../index.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Faturamento total
|--------------------------------------------------------------------------
*/

$sqlFaturamento = "
    SELECT COALESCE(SUM(valor_total), 0) AS total
    FROM locacoes
    WHERE status = 'Finalizada'
";

$resultadoFaturamento =
    $conexao->query($sqlFaturamento);

$faturamentoTotal =
    $resultadoFaturamento
        ->fetch_assoc()['total'];


/*
|--------------------------------------------------------------------------
| Quantidade de locações finalizadas
|--------------------------------------------------------------------------
*/

$sqlFinalizadas = "
    SELECT COUNT(*) AS total
    FROM locacoes
    WHERE status = 'Finalizada'
";

$resultadoFinalizadas =
    $conexao->query($sqlFinalizadas);

$totalFinalizadas =
    $resultadoFinalizadas
        ->fetch_assoc()['total'];


/*
|--------------------------------------------------------------------------
| Locações em andamento
|--------------------------------------------------------------------------
*/

$sqlAndamento = "
    SELECT COUNT(*) AS total
    FROM locacoes
    WHERE status = 'Em andamento'
";

$resultadoAndamento =
    $conexao->query($sqlAndamento);

$totalAndamento =
    $resultadoAndamento
        ->fetch_assoc()['total'];


/*
|--------------------------------------------------------------------------
| Ticket médio
|--------------------------------------------------------------------------
*/

if ($totalFinalizadas > 0) {

    $ticketMedio =
        $faturamentoTotal /
        $totalFinalizadas;

} else {

    $ticketMedio = 0;
}


/*
|--------------------------------------------------------------------------
| Histórico financeiro
|--------------------------------------------------------------------------
*/

$sqlHistorico = "
    SELECT
        locacoes.id,
        clientes.nome AS cliente,
        veiculos.marca,
        veiculos.modelo,
        locacoes.valor_total,
        locacoes.data_retirada,
        locacoes.data_devolucao,
        locacoes.status

    FROM locacoes

    INNER JOIN clientes
        ON locacoes.cliente_id = clientes.id

    INNER JOIN veiculos
        ON locacoes.veiculo_id = veiculos.id

    ORDER BY locacoes.id DESC
";

$historico =
    $conexao->query($sqlHistorico);

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Financeiro - Royale Cars
    </title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >

</head>

<body>

    <aside class="sidebar">

        <div class="logo">

            <h2>
                ROYALE
                <span>CARS</span>
            </h2>

        </div>

        <nav class="menu">

            <a href="../dashboard.php">
                Dashboard
            </a>

            <a href="../veiculos/index.php">
                Frota de Veículos
            </a>

            <a href="../clientes/index.php">
                Clientes
            </a>

            <a href="../locacoes/index.php">
                Locações
            </a>

            <a
                href="index.php"
                class="active"
            >
                Financeiro
            </a>

            <a href="../configuracoes/index.php">
                Configurações
            </a>

            <a href="../logout.php">
                Sair
            </a>

        </nav>

    </aside>


    <main class="main">

        <header class="topbar">

            <h1>
                Financeiro
            </h1>

            <span>
                Olá,
                <?= htmlspecialchars(
                    $_SESSION['usuario_nome']
                ) ?>
            </span>

        </header>


        <section class="content">

            <div class="page-header">

                <div>

                    <h2>
                        Visão financeira
                    </h2>

                    <p>
                        Acompanhe os resultados da Royale Cars.
                    </p>

                </div>

            </div>


            <!-- CARDS -->

            <div class="cards">

                <div class="card">

                    <h3>
                        FATURAMENTO TOTAL
                    </h3>

                    <div class="valor">

                        R$
                        <?= number_format(
                            $faturamentoTotal,
                            2,
                            ',',
                            '.'
                        ) ?>

                    </div>

                </div>


                <div class="card">

                    <h3>
                        LOCAÇÕES FINALIZADAS
                    </h3>

                    <div class="valor">

                        <?= $totalFinalizadas ?>

                    </div>

                </div>


                <div class="card">

                    <h3>
                        LOCAÇÕES EM ANDAMENTO
                    </h3>

                    <div class="valor">

                        <?= $totalAndamento ?>

                    </div>

                </div>


                <div class="card">

                    <h3>
                        TICKET MÉDIO
                    </h3>

                    <div class="valor">

                        R$
                        <?= number_format(
                            $ticketMedio,
                            2,
                            ',',
                            '.'
                        ) ?>

                    </div>

                </div>

            </div>


            <!-- HISTÓRICO -->

            <div
                class="form-container"
                style="margin-top: 30px;"
            >

                <div class="page-header">

                    <div>

                        <h2>
                            Histórico financeiro
                        </h2>

                        <p>
                            Valores registrados nas locações.
                        </p>

                    </div>

                </div>


                <div class="table-container">

                    <table>

                        <thead>

                            <tr>

                                <th>ID</th>

                                <th>Cliente</th>

                                <th>Veículo</th>

                                <th>Retirada</th>

                                <th>Devolução</th>

                                <th>Valor</th>

                                <th>Status</th>

                            </tr>

                        </thead>


                        <tbody>

                            <?php if (
                                $historico &&
                                $historico->num_rows > 0
                            ): ?>

                                <?php while (
                                    $item =
                                    $historico->fetch_assoc()
                                ): ?>

                                    <tr>

                                        <td>
                                            <?= $item['id'] ?>
                                        </td>

                                        <td>

                                            <?= htmlspecialchars(
                                                $item['cliente']
                                            ) ?>

                                        </td>

                                        <td>

                                            <?= htmlspecialchars(
                                                $item['marca']
                                            ) ?>

                                            <?= htmlspecialchars(
                                                $item['modelo']
                                            ) ?>

                                        </td>

                                        <td>

                                            <?= date(
                                                'd/m/Y',
                                                strtotime(
                                                    $item[
                                                        'data_retirada'
                                                    ]
                                                )
                                            ) ?>

                                        </td>

                                        <td>

                                            <?= date(
                                                'd/m/Y',
                                                strtotime(
                                                    $item[
                                                        'data_devolucao'
                                                    ]
                                                )
                                            ) ?>

                                        </td>

                                        <td>

                                            R$
                                            <?= number_format(
                                                $item['valor_total'],
                                                2,
                                                ',',
                                                '.'
                                            ) ?>

                                        </td>

                                        <td>

                                            <span class="status">

                                                <?= htmlspecialchars(
                                                    $item['status']
                                                ) ?>

                                            </span>

                                        </td>

                                    </tr>

                                <?php endwhile; ?>

                            <?php else: ?>

                                <tr>

                                    <td
                                        colspan="7"
                                        class="empty"
                                    >

                                        Nenhuma movimentação
                                        financeira registrada.

                                    </td>

                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </section>

    </main>

</body>

</html>