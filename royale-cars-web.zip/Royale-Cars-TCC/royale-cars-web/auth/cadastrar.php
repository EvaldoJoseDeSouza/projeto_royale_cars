```php
<?php

require_once '../config/database.php';

$mensagem = '';
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $senha = $_POST['senha'];

    if (
        empty($nome) ||
        empty($email) ||
        empty($senha)
    ) {

        $erro = 'Preencha todos os campos.';

    } elseif (strlen($senha) < 6) {

        $erro = 'A senha deve ter pelo menos 6 caracteres.';

    } else {

        $senhaHash = password_hash(
            $senha,
            PASSWORD_DEFAULT
        );

        $sql = 'INSERT INTO usuarios
                (nome, email, senha)
                VALUES (?, ?, ?)';

        $stmt = $conexao->prepare($sql);

        $stmt->bind_param(
            'sss',
            $nome,
            $email,
            $senhaHash
        );

        if ($stmt->execute()) {

            $mensagem =
                'Usuário cadastrado com sucesso! '
                . 'Agora você pode fazer login.';

        } else {

            if ($conexao->errno === 1062) {

                $erro =
                    'Este e-mail já está cadastrado.';

            } else {

                $erro =
                    'Erro ao cadastrar usuário.';
            }
        }

        $stmt->close();
    }
}

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Cadastro - Royale Cars</title>

    <link rel="stylesheet"
          href="../css/style.css">

</head>

<body class="login-body">

    <div class="login-container">

        <div class="login-card">

            <div class="login-logo">

                <h1>
                    ROYALE
                    <span>CARS</span>
                </h1>

                <p>
                    Criar usuário
                </p>

            </div>

            <?php if ($erro): ?>

                <div class="alert-error">

                    <?= htmlspecialchars($erro) ?>

                </div>

            <?php endif; ?>


            <?php if ($mensagem): ?>

                <div class="alert-success">

                    <?= htmlspecialchars($mensagem) ?>

                </div>

            <?php endif; ?>


            <form method="POST">

                <div class="form-group">

                    <label for="nome">
                        Nome
                    </label>

                    <input
                        type="text"
                        id="nome"
                        name="nome"
                        placeholder="Digite seu nome"
                        required
                    >

                </div>


                <div class="form-group">

                    <label for="email">
                        E-mail
                    </label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="Digite seu e-mail"
                        required
                    >

                </div>


                <div class="form-group">

                    <label for="senha">
                        Senha
                    </label>

                    <input
                        type="password"
                        id="senha"
                        name="senha"
                        placeholder="Mínimo de 6 caracteres"
                        required
                    >

                </div>


                <button
                    type="submit"
                    class="btn-login">

                    CADASTRAR

                </button>

            </form>

            <br>

            <div style="text-align: center;">

                <a href="../index.php">
                    Voltar para o login
                </a>

            </div>

        </div>

    </div>

</body>

</html>
```