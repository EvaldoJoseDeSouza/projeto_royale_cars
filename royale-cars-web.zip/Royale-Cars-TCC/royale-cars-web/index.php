<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config/database.php';

// Se já estiver logado, vai para o dashboard.
if (isset($_SESSION['usuario_id'])) {
    header('Location: dashboard.php');
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email']);
    $senha = $_POST['senha'];

    if (empty($email) || empty($senha)) {

        $erro = 'Preencha todos os campos.';

    } else {

        $sql = 'SELECT id, nome, email, senha
                FROM usuarios
                WHERE email = ?';

        $stmt = $conexao->prepare($sql);

        $stmt->bind_param('s', $email);

        $stmt->execute();

        $resultado = $stmt->get_result();

        if ($resultado->num_rows === 1) {

            $usuario = $resultado->fetch_assoc();

            if (password_verify($senha, $usuario['senha'])) {

                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['usuario_nome'] = $usuario['nome'];
                $_SESSION['usuario_email'] = $usuario['email'];

                header('Location: dashboard.php');
                exit;

            } else {

                $erro = 'E-mail ou senha incorretos.';
            }

        } else {

            $erro = 'E-mail ou senha incorretos.';
        }

        $stmt->close();
    }
}

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Royale Cars - Login</title>

    <link rel="stylesheet"
          href="css/style.css">

</head>

<body class="login-body">

    <div class="login-container">

        <div class="login-card">

            <div class="login-logo">

                <h1>
                    ROYALE
                    <span>CARS</span>
                </h1>

                <p>
                    Sistema de Gestão
                </p>

            </div>

            <h2>
                Entrar
            </h2>

            <?php if ($erro): ?>

                <div class="alert-error">
                    <?= htmlspecialchars($erro) ?>
                </div>

            <?php endif; ?>

            <form method="POST">

                <div class="form-group">

                    <label for="email">
                        E-mail
                    </label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="Digite seu e-mail"
                        required
                    >

                </div>

                <div class="form-group">

                    <label for="senha">
                        Senha
                    </label>

                    <input
                        type="password"
                        id="senha"
                        name="senha"
                        placeholder="Digite sua senha"
                        required
                    >

                </div>

                <button
                    type="submit"
                    class="btn-login">

                    ENTRAR

                </button>

            </form>

            <div style="text-align: center; margin-top: 20px;">

                <a href="auth/cadastrar.php">
                    Criar uma conta
                </a>

            </div>

        </div>

    </div>

</body>

</html>