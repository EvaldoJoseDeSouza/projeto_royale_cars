<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../index.php');
    exit;
}

$busca = trim($_GET['busca'] ?? '');

if ($busca !== '') {

    $sql = "
        SELECT *
        FROM clientes
        WHERE arquivado = FALSE
        AND (
            nome LIKE ?
            OR cpf LIKE ?
            OR email LIKE ?
        )
        ORDER BY id DESC
    ";

    $stmt = $conexao->prepare($sql);

    $termo = "%$busca%";

    $stmt->bind_param(
        'sss',
        $termo,
        $termo,
        $termo
    );

    $stmt->execute();

    $clientes = $stmt->get_result();

} else {

    $sql = "
        SELECT *
        FROM clientes
        WHERE arquivado = FALSE
        ORDER BY id DESC
    ";

    $clientes = $conexao->query($sql);
}

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Royale Cars - Clientes</title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >

</head>

<body>

    <aside class="sidebar">

        <div class="logo">

            <h2>
                ROYALE
                <span>CARS</span>
            </h2>

        </div>

        <nav class="menu">

            <a href="../dashboard.php">
                Dashboard
            </a>

            <a href="../veiculos/index.php">
                Frota de Veículos
            </a>

            <a
                href="index.php"
                class="active"
            >
                Clientes
            </a>

            <a href="../locacoes/index.php">
                Locações
            </a>

            <a href="../financeiro/index.php">
                Financeiro
            </a>

            <a href="../configuracoes/index.php">
                Configurações
            </a>

            <a href="../logout.php">
                Sair
            </a>

        </nav>

    </aside>


    <main class="main">

        <header class="topbar">

            <h1>
                Clientes
            </h1>

            <span>
                Olá,
                <?= htmlspecialchars($_SESSION['usuario_nome']) ?>
            </span>

        </header>


        <section class="content">

            <div class="page-header">

                <div>

                    <h2>
                        Clientes cadastrados
                    </h2>

                    <p>
                        Gerencie os clientes da Royale Cars.
                    </p>

                </div>

                <a
                    href="cadastrar.php"
                    class="btn-primary"
                >
                    + Cadastrar cliente
                </a>

            </div>


            <form
                method="GET"
                class="search-box"
            >

                <input
                    type="text"
                    name="busca"
                    value="<?= htmlspecialchars($busca) ?>"
                    placeholder="Buscar por nome, CPF ou e-mail..."
                >

                <button
                    type="submit"
                    class="btn-primary"
                >
                    Buscar
                </button>

            </form>


            <div class="table-container">

                <table>

                    <thead>

                        <tr>

                            <th>ID</th>

                            <th>Nome</th>

                            <th>CPF</th>

                            <th>E-mail</th>

                            <th>Telefone</th>

                            <th>Ações</th>

                        </tr>

                    </thead>


                    <tbody>

                        <?php if ($clientes && $clientes->num_rows > 0): ?>

                            <?php while ($cliente = $clientes->fetch_assoc()): ?>

                                <tr>

                                    <td>
                                        <?= $cliente['id'] ?>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars($cliente['nome']) ?>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars($cliente['cpf']) ?>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars($cliente['email'] ?? '') ?>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars($cliente['telefone'] ?? '') ?>
                                    </td>

                                    <td>

                                        <a
                                            href="editar.php?id=<?= $cliente['id'] ?>"
                                            class="btn-small"
                                        >
                                            Editar
                                        </a>

                                        <a
                                            href="excluir.php?id=<?= $cliente['id'] ?>"
                                            class="btn-small btn-danger"
                                            onclick="return confirm('Deseja arquivar este cliente?');"
                                        >
                                            Arquivar
                                        </a>

                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>

                                <td
                                    colspan="6"
                                    class="empty"
                                >
                                    Nenhum cliente encontrado.
                                </td>

                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </section>

    </main>

</body>

</html>