<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../index.php');
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome = trim($_POST['nome'] ?? '');
    $cpf = trim($_POST['cpf'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');

    if ($nome === '' || $cpf === '') {

        $erro = 'Nome e CPF são obrigatórios.';

    } elseif (
        $email !== '' &&
        !filter_var($email, FILTER_VALIDATE_EMAIL)
    ) {

        $erro = 'Digite um e-mail válido.';

    } else {

        // Verificar se o CPF já existe
        $sqlCpf = "
            SELECT id
            FROM clientes
            WHERE cpf = ?
        ";

        $stmtCpf = $conexao->prepare($sqlCpf);
        $stmtCpf->bind_param('s', $cpf);
        $stmtCpf->execute();

        $resultadoCpf = $stmtCpf->get_result();

        if ($resultadoCpf->num_rows > 0) {

            $erro = 'Este CPF já está cadastrado.';

            $stmtCpf->close();

        } else {

            $stmtCpf->close();

            $sql = "
                INSERT INTO clientes
                (
                    nome,
                    cpf,
                    email,
                    telefone
                )
                VALUES (?, ?, ?, ?)
            ";

            $stmt = $conexao->prepare($sql);

            $stmt->bind_param(
                'ssss',
                $nome,
                $cpf,
                $email,
                $telefone
            );

            if ($stmt->execute()) {

                $stmt->close();

                header('Location: index.php');
                exit;

            } else {

                $erro = 'Erro ao cadastrar cliente: '
                    . $conexao->error;

                $stmt->close();
            }
        }
    }
}

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Cadastrar Cliente - Royale Cars
    </title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >

</head>

<body>

    <aside class="sidebar">

        <div class="logo">

            <h2>
                ROYALE
                <span>CARS</span>
            </h2>

        </div>

        <nav class="menu">

            <a href="../dashboard.php">
                Dashboard
            </a>

            <a href="../veiculos/index.php">
                Frota de Veículos
            </a>

            <a
                href="index.php"
                class="active"
            >
                Clientes
            </a>

            <a href="../locacoes/index.php">
                Locações
            </a>

            <a href="../financeiro/index.php">
                Financeiro
            </a>

            <a href="../configuracoes/index.php">
                Configurações
            </a>

            <a href="../logout.php">
                Sair
            </a>

        </nav>

    </aside>


    <main class="main">

        <header class="topbar">

            <h1>
                Cadastrar Cliente
            </h1>

            <span>
                Olá,
                <?= htmlspecialchars($_SESSION['usuario_nome']) ?>
            </span>

        </header>


        <section class="content">

            <div class="form-container">

                <div class="page-header">

                    <div>

                        <h2>
                            Novo cliente
                        </h2>

                        <p>
                            Preencha os dados do cliente.
                        </p>

                    </div>

                    <a
                        href="index.php"
                        class="btn-secondary"
                    >
                        Voltar
                    </a>

                </div>


                <?php if ($erro): ?>

                    <div class="alert-error">

                        <?= htmlspecialchars($erro) ?>

                    </div>

                <?php endif; ?>


                <form method="POST">

                    <div class="form-grid">

                        <div class="form-group">

                            <label for="nome">
                                Nome completo *
                            </label>

                            <input
                                type="text"
                                id="nome"
                                name="nome"
                                placeholder="Digite o nome completo"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label for="cpf">
                                CPF *
                            </label>

                            <input
                                type="text"
                                id="cpf"
                                name="cpf"
                                placeholder="000.000.000-00"
                                maxlength="20"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label for="email">
                                E-mail
                            </label>

                            <input
                                type="email"
                                id="email"
                                name="email"
                                placeholder="cliente@email.com"
                            >

                        </div>


                        <div class="form-group">

                            <label for="telefone">
                                Telefone
                            </label>

                            <input
                                type="text"
                                id="telefone"
                                name="telefone"
                                placeholder="(19) 99999-9999"
                                maxlength="30"
                            >

                        </div>

                    </div>


                    <div class="form-actions">

                        <a
                            href="index.php"
                            class="btn-secondary"
                        >
                            Cancelar
                        </a>

                        <button
                            type="submit"
                            class="btn-primary"
                        >
                            Cadastrar cliente
                        </button>

                    </div>

                </form>

            </div>

        </section>

    </main>

</body>

</html>