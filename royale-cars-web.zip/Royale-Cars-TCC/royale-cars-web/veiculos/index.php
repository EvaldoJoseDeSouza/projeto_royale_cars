<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../index.php');
    exit;
}

$busca = trim($_GET['busca'] ?? '');

if ($busca !== '') {

    $sql = "
        SELECT *
        FROM veiculos
        WHERE arquivado = FALSE
        AND (
            marca LIKE ?
            OR modelo LIKE ?
            OR placa LIKE ?
        )
        ORDER BY id DESC
    ";

    $stmt = $conexao->prepare($sql);

    $termo = "%$busca%";

    $stmt->bind_param(
        'sss',
        $termo,
        $termo,
        $termo
    );

    $stmt->execute();

    $veiculos = $stmt->get_result();

} else {

    $sql = "
        SELECT *
        FROM veiculos
        WHERE arquivado = FALSE
        ORDER BY id DESC
    ";

    $veiculos = $conexao->query($sql);
}

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Royale Cars - Veículos</title>

    <link rel="stylesheet"
          href="../css/style.css">

</head>

<body>

    <aside class="sidebar">

        <div class="logo">

            <h2>
                ROYALE
                <span>CARS</span>
            </h2>

        </div>

        <nav class="menu">

            <a href="../dashboard.php">
                Dashboard
            </a>

            <a href="index.php"
               class="active">
                Frota de Veículos
            </a>

            <a href="../clientes/index.php">
                Clientes
            </a>

            <a href="../locacoes/index.php">
                Locações
            </a>

            <a href="../financeiro/index.php">
                Financeiro
            </a>

            <a href="../configuracoes/index.php">
                Configurações
            </a>

            <a href="../logout.php">
                Sair
            </a>

        </nav>

    </aside>


    <main class="main">

        <header class="topbar">

            <h1>
                Frota de Veículos
            </h1>

            <span>
                Olá,
                <?= htmlspecialchars($_SESSION['usuario_nome']) ?>
            </span>

        </header>


        <section class="content">

            <div class="page-header">

                <div>

                    <h2>
                        Veículos cadastrados
                    </h2>

                    <p>
                        Gerencie os veículos da Royale Cars.
                    </p>

                </div>

                <a
                    href="cadastrar.php"
                    class="btn-primary">

                    + Cadastrar veículo

                </a>

            </div>


            <form
                method="GET"
                class="search-box">

                <input
                    type="text"
                    name="busca"
                    value="<?= htmlspecialchars($busca) ?>"
                    placeholder="Buscar por marca, modelo ou placa..."
                >

                <button
                    type="submit"
                    class="btn-primary">

                    Buscar

                </button>

            </form>


            <div class="table-container">

                <table>

                    <thead>

                        <tr>

                            <th>ID</th>

                            <th>Marca</th>

                            <th>Modelo</th>

                            <th>Ano</th>

                            <th>Placa</th>

                            <th>Valor diária</th>

                            <th>Status</th>

                            <th>Ações</th>

                        </tr>

                    </thead>


                    <tbody>

                        <?php if ($veiculos->num_rows > 0): ?>

                            <?php while ($veiculo = $veiculos->fetch_assoc()): ?>

                                <tr>

                                    <td>
                                        <?= $veiculo['id'] ?>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars(
                                            $veiculo['marca']
                                        ) ?>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars(
                                            $veiculo['modelo']
                                        ) ?>
                                    </td>

                                    <td>
                                        <?= $veiculo['ano'] ?>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars(
                                            $veiculo['placa']
                                        ) ?>
                                    </td>

                                    <td>

                                        R$
                                        <?= number_format(
                                            $veiculo['valor_diaria'],
                                            2,
                                            ',',
                                            '.'
                                        ) ?>

                                    </td>

                                    <td>

                                        <span class="status">

                                            <?= htmlspecialchars(
                                                $veiculo['status']
                                            ) ?>

                                        </span>

                                    </td>

                                    <td>

                                        <a
                                            href="editar.php?id=<?= $veiculo['id'] ?>"
                                            class="btn-small">

                                            Editar

                                        </a>

                                        <a
                                            href="excluir.php?id=<?= $veiculo['id'] ?>"
                                            class="btn-small btn-danger"
                                            onclick="return confirm('Deseja arquivar este veículo?');">

                                            Arquivar

                                        </a>

                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>

                                <td
                                    colspan="8"
                                    class="empty">

                                    Nenhum veículo encontrado.

                                </td>

                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </section>

    </main>

</body>

</html>