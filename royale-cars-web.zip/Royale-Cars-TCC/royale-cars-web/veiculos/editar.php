<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../index.php');
    exit;
}

$id = intval($_GET['id'] ?? 0);

if ($id <= 0) {
    header('Location: index.php');
    exit;
}


/*
|--------------------------------------------------------------------------
| Buscar veículo
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT *
    FROM veiculos
    WHERE id = ?
";

$stmt = $conexao->prepare($sql);

$stmt->bind_param('i', $id);

$stmt->execute();

$resultado = $stmt->get_result();

if ($resultado->num_rows !== 1) {

    header('Location: index.php');
    exit;
}

$veiculo = $resultado->fetch_assoc();

$stmt->close();


$erro = '';


/*
|--------------------------------------------------------------------------
| Atualizar veículo
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $marca = trim($_POST['marca']);
    $modelo = trim($_POST['modelo']);
    $ano = intval($_POST['ano']);
    $placa = strtoupper(trim($_POST['placa']));
    $valor_diaria = floatval($_POST['valor_diaria']);
    $status = $_POST['status'];

    if (
        empty($marca) ||
        empty($modelo) ||
        empty($ano) ||
        empty($placa) ||
        $valor_diaria <= 0
    ) {

        $erro =
            'Preencha todos os campos corretamente.';

    } else {

        $sql = "
            UPDATE veiculos
            SET
                marca = ?,
                modelo = ?,
                ano = ?,
                placa = ?,
                valor_diaria = ?,
                status = ?
            WHERE id = ?
        ";

        $stmt = $conexao->prepare($sql);

        $stmt->bind_param(
            'ssisdsi',
            $marca,
            $modelo,
            $ano,
            $placa,
            $valor_diaria,
            $status,
            $id
        );

        if ($stmt->execute()) {

            header('Location: index.php');
            exit;

        } else {

            $erro =
                'Erro ao atualizar o veículo.';
        }

        $stmt->close();
    }
}

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Editar Veículo - Royale Cars
    </title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >

</head>

<body>

    <aside class="sidebar">

        <div class="logo">

            <h2>
                ROYALE
                <span>CARS</span>
            </h2>

        </div>

        <nav class="menu">

            <a href="../dashboard.php">
                Dashboard
            </a>

            <a
                href="index.php"
                class="active"
            >
                Frota de Veículos
            </a>

            <a href="../clientes/index.php">
                Clientes
            </a>

            <a href="../locacoes/index.php">
                Locações
            </a>

            <a href="../financeiro/index.php">
                Financeiro
            </a>

            <a href="../configuracoes/index.php">
                Configurações
            </a>

            <a href="../logout.php">
                Sair
            </a>

        </nav>

    </aside>


    <main class="main">

        <header class="topbar">

            <h1>
                Editar Veículo
            </h1>

            <span>
                Olá,
                <?= htmlspecialchars($_SESSION['usuario_nome']) ?>
            </span>

        </header>


        <section class="content">

            <div class="form-container">

                <div class="page-header">

                    <div>

                        <h2>
                            Editar veículo
                        </h2>

                        <p>
                            Altere as informações do veículo.
                        </p>

                    </div>

                    <a
                        href="index.php"
                        class="btn-secondary"
                    >
                        Voltar
                    </a>

                </div>


                <?php if ($erro): ?>

                    <div class="alert-error">

                        <?= htmlspecialchars($erro) ?>

                    </div>

                <?php endif; ?>


                <form method="POST">

                    <div class="form-grid">

                        <div class="form-group">

                            <label for="marca">
                                Marca
                            </label>

                            <input
                                type="text"
                                id="marca"
                                name="marca"
                                value="<?= htmlspecialchars($veiculo['marca']) ?>"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label for="modelo">
                                Modelo
                            </label>

                            <input
                                type="text"
                                id="modelo"
                                name="modelo"
                                value="<?= htmlspecialchars($veiculo['modelo']) ?>"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label for="ano">
                                Ano
                            </label>

                            <input
                                type="number"
                                id="ano"
                                name="ano"
                                value="<?= $veiculo['ano'] ?>"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label for="placa">
                                Placa
                            </label>

                            <input
                                type="text"
                                id="placa"
                                name="placa"
                                value="<?= htmlspecialchars($veiculo['placa']) ?>"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label for="valor_diaria">
                                Valor da diária
                            </label>

                            <input
                                type="number"
                                id="valor_diaria"
                                name="valor_diaria"
                                step="0.01"
                                value="<?= $veiculo['valor_diaria'] ?>"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label for="status">
                                Status
                            </label>

                            <select
                                id="status"
                                name="status"
                            >

                                <option
                                    value="Disponível"
                                    <?= $veiculo['status'] === 'Disponível' ? 'selected' : '' ?>
                                >
                                    Disponível
                                </option>

                                <option
                                    value="Alugado"
                                    <?= $veiculo['status'] === 'Alugado' ? 'selected' : '' ?>
                                >
                                    Alugado
                                </option>

                                <option
                                    value="Em Manutenção"
                                    <?= $veiculo['status'] === 'Em Manutenção' ? 'selected' : '' ?>
                                >
                                    Em Manutenção
                                </option>

                            </select>

                        </div>

                    </div>


                    <div class="form-actions">

                        <a
                            href="index.php"
                            class="btn-secondary"
                        >
                            Cancelar
                        </a>

                        <button
                            type="submit"
                            class="btn-primary"
                        >
                            Salvar alterações
                        </button>

                    </div>

                </form>

            </div>

        </section>

    </main>

</body>

</html>