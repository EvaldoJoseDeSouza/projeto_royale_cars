<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../index.php');
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $marca = trim($_POST['marca']);
    $modelo = trim($_POST['modelo']);
    $ano = intval($_POST['ano']);
    $placa = strtoupper(trim($_POST['placa']));
    $valor_diaria = floatval($_POST['valor_diaria']);
    $status = $_POST['status'];

    if (
        empty($marca) ||
        empty($modelo) ||
        empty($ano) ||
        empty($placa) ||
        $valor_diaria <= 0
    ) {

        $erro = 'Preencha todos os campos corretamente.';

    } else {

        $sql = "
            INSERT INTO veiculos
            (
                marca,
                modelo,
                ano,
                placa,
                valor_diaria,
                status
            )
            VALUES (?, ?, ?, ?, ?, ?)
        ";

        $stmt = $conexao->prepare($sql);

     $stmt->bind_param(
        'ssisds',
        $marca,
        $modelo,
        $ano,
        $placa,
        $valor_diaria,
        $status
    );

        if ($stmt->execute()) {

            header('Location: index.php');
            exit;

        } else {

            if ($conexao->errno === 1062) {

                $erro = 'A placa informada já está cadastrada.';

            } else {

                 $erro = 'Erro ao cadastrar o veículo: ' . $conexao->error;
            }
        }

        $stmt->close();
    }
}

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Cadastrar Veículo - Royale Cars
    </title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >

</head>

<body>

    <aside class="sidebar">

        <div class="logo">

            <h2>
                ROYALE
                <span>CARS</span>
            </h2>

        </div>

        <nav class="menu">

            <a href="../dashboard.php">
                Dashboard
            </a>

            <a
                href="index.php"
                class="active"
            >
                Frota de Veículos
            </a>

            <a href="../clientes/index.php">
                Clientes
            </a>

            <a href="../locacoes/index.php">
                Locações
            </a>

            <a href="../financeiro/index.php">
                Financeiro
            </a>

            <a href="../configuracoes/index.php">
                Configurações
            </a>

            <a href="../logout.php">
                Sair
            </a>

        </nav>

    </aside>


    <main class="main">

        <header class="topbar">

            <h1>
                Cadastrar Veículo
            </h1>

            <span>
                Olá,
                <?= htmlspecialchars($_SESSION['usuario_nome']) ?>
            </span>

        </header>


        <section class="content">

            <div class="form-container">

                <div class="page-header">

                    <div>

                        <h2>
                            Novo veículo
                        </h2>

                        <p>
                            Preencha os dados do veículo.
                        </p>

                    </div>

                    <a
                        href="index.php"
                        class="btn-secondary"
                    >
                        Voltar
                    </a>

                </div>


                <?php if ($erro): ?>

                    <div class="alert-error">

                        <?= htmlspecialchars($erro) ?>

                    </div>

                <?php endif; ?>


                <form method="POST">

                    <div class="form-grid">

                        <div class="form-group">

                            <label for="marca">
                                Marca
                            </label>

                            <input
                                type="text"
                                id="marca"
                                name="marca"
                                placeholder="Ex.: Toyota"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label for="modelo">
                                Modelo
                            </label>

                            <input
                                type="text"
                                id="modelo"
                                name="modelo"
                                placeholder="Ex.: Corolla"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label for="ano">
                                Ano
                            </label>

                            <input
                                type="number"
                                id="ano"
                                name="ano"
                                min="1900"
                                max="2100"
                                placeholder="Ex.: 2025"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label for="placa">
                                Placa
                            </label>

                            <input
                                type="text"
                                id="placa"
                                name="placa"
                                placeholder="Ex.: ABC1D23"
                                maxlength="8"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label for="valor_diaria">
                                Valor da diária
                            </label>

                            <input
                                type="number"
                                id="valor_diaria"
                                name="valor_diaria"
                                step="0.01"
                                min="0"
                                placeholder="Ex.: 250.00"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label for="status">
                                Status
                            </label>

                            <select
                                id="status"
                                name="status"
                            >

                                <option value="Disponível">
                                    Disponível
                                </option>

                                <option value="Alugado">
                                    Alugado
                                </option>

                                <option value="Em Manutenção">
                                    Em Manutenção
                                </option>

                            </select>

                        </div>

                    </div>


                    <div class="form-actions">

                        <a
                            href="index.php"
                            class="btn-secondary"
                        >
                            Cancelar
                        </a>

                        <button
                            type="submit"
                            class="btn-primary"
                        >
                            Cadastrar veículo
                        </button>

                    </div>

                </form>

            </div>

        </section>

    </main>

</body>

</html>