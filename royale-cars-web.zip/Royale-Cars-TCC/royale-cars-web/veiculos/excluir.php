<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../index.php');
    exit;
}

$id = intval($_GET['id'] ?? 0);

if ($id > 0) {

    $sql = "
        UPDATE veiculos
        SET arquivado = TRUE
        WHERE id = ?
    ";

    $stmt = $conexao->prepare($sql);

    $stmt->bind_param('i', $id);

    $stmt->execute();

    $stmt->close();
}

header('Location: index.php');

exit;