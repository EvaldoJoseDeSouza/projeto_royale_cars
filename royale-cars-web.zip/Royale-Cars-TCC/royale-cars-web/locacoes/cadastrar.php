<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../index.php');
    exit;
}

$erro = '';

/*
|--------------------------------------------------------------------------
| Buscar clientes
|--------------------------------------------------------------------------
*/

$sqlClientes = "
    SELECT id, nome
    FROM clientes
    WHERE arquivado = FALSE
    ORDER BY nome
";

$clientes = $conexao->query($sqlClientes);


/*
|--------------------------------------------------------------------------
| Buscar veículos disponíveis
|--------------------------------------------------------------------------
*/

$sqlVeiculos = "
    SELECT id, marca, modelo, placa, valor_diaria
    FROM veiculos
    WHERE arquivado = FALSE
    AND status = 'Disponível'
    ORDER BY marca, modelo
";

$veiculos = $conexao->query($sqlVeiculos);


/*
|--------------------------------------------------------------------------
| Cadastrar locação
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $cliente_id = intval($_POST['cliente_id']);
    $veiculo_id = intval($_POST['veiculo_id']);
    $data_retirada = $_POST['data_retirada'];
    $data_devolucao = $_POST['data_devolucao'];

    if (
        $cliente_id <= 0 ||
        $veiculo_id <= 0 ||
        empty($data_retirada) ||
        empty($data_devolucao)
    ) {

        $erro = 'Preencha todos os campos.';

    } elseif ($data_devolucao < $data_retirada) {

        $erro =
            'A data de devolução não pode ser anterior à retirada.';

    } else {

        /*
        |--------------------------------------------------------------------------
        | Buscar valor da diária
        |--------------------------------------------------------------------------
        */

        $sqlVeiculo = "
            SELECT valor_diaria
            FROM veiculos
            WHERE id = ?
            AND status = 'Disponível'
            AND arquivado = FALSE
        ";

        $stmtVeiculo = $conexao->prepare($sqlVeiculo);

        $stmtVeiculo->bind_param(
            'i',
            $veiculo_id
        );

        $stmtVeiculo->execute();

        $resultadoVeiculo =
            $stmtVeiculo->get_result();

        if ($resultadoVeiculo->num_rows !== 1) {

            $erro =
                'O veículo selecionado não está disponível.';

        } else {

            $veiculo =
                $resultadoVeiculo->fetch_assoc();

            $valor_diaria =
                floatval($veiculo['valor_diaria']);

            /*
            |--------------------------------------------------------------------------
            | Calcular quantidade de dias
            |--------------------------------------------------------------------------
            */

            $inicio = new DateTime($data_retirada);

            $fim = new DateTime($data_devolucao);

            $dias = $inicio->diff($fim)->days;

            if ($dias <= 0) {
                $dias = 1;
            }

            $valor_total =
                $dias * $valor_diaria;


            /*
            |--------------------------------------------------------------------------
            | Inserir locação
            |--------------------------------------------------------------------------
            */

            $sql = "
                INSERT INTO locacoes
                (
                    cliente_id,
                    veiculo_id,
                    data_retirada,
                    data_devolucao,
                    valor_total,
                    status
                )
                VALUES (?, ?, ?, ?, ?, 'Em andamento')
            ";

            $stmt = $conexao->prepare($sql);

            $stmt->bind_param(
                'iissd',
                $cliente_id,
                $veiculo_id,
                $data_retirada,
                $data_devolucao,
                $valor_total
            );

            if ($stmt->execute()) {

                /*
                |--------------------------------------------------------------------------
                | Alterar status do veículo
                |--------------------------------------------------------------------------
                */

                $sqlStatus = "
                    UPDATE veiculos
                    SET status = 'Alugado'
                    WHERE id = ?
                ";

                $stmtStatus =
                    $conexao->prepare($sqlStatus);

                $stmtStatus->bind_param(
                    'i',
                    $veiculo_id
                );

                $stmtStatus->execute();

                $stmtStatus->close();

                header('Location: index.php');

                exit;

            } else {

                $erro =
                    'Erro ao cadastrar a locação.';
            }

            $stmt->close();
        }

        $stmtVeiculo->close();
    }
}

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Nova Locação - Royale Cars
    </title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >

</head>

<body>

    <aside class="sidebar">

        <div class="logo">

            <h2>
                ROYALE
                <span>CARS</span>
            </h2>

        </div>

        <nav class="menu">

            <a href="../dashboard.php">
                Dashboard
            </a>

            <a href="../veiculos/index.php">
                Frota de Veículos
            </a>

            <a href="../clientes/index.php">
                Clientes
            </a>

            <a
                href="index.php"
                class="active"
            >
                Locações
            </a>

            <a href="../financeiro/index.php">
                Financeiro
            </a>

            <a href="../configuracoes/index.php">
                Configurações
            </a>

            <a href="../logout.php">
                Sair
            </a>

        </nav>

    </aside>


    <main class="main">

        <header class="topbar">

            <h1>
                Nova Locação
            </h1>

            <span>
                Olá,
                <?= htmlspecialchars($_SESSION['usuario_nome']) ?>
            </span>

        </header>


        <section class="content">

            <div class="form-container">

                <div class="page-header">

                    <div>

                        <h2>
                            Criar locação
                        </h2>

                        <p>
                            Selecione o cliente, veículo e período.
                        </p>

                    </div>

                    <a
                        href="index.php"
                        class="btn-secondary"
                    >
                        Voltar
                    </a>

                </div>


                <?php if ($erro): ?>

                    <div class="alert-error">

                        <?= htmlspecialchars($erro) ?>

                    </div>

                <?php endif; ?>


                <form method="POST">

                    <div class="form-grid">

                        <div class="form-group">

                            <label for="cliente_id">
                                Cliente
                            </label>

                            <select
                                id="cliente_id"
                                name="cliente_id"
                                required
                            >

                                <option value="">
                                    Selecione um cliente
                                </option>

                                <?php while ($cliente = $clientes->fetch_assoc()): ?>

                                    <option
                                        value="<?= $cliente['id'] ?>"
                                    >

                                        <?= htmlspecialchars(
                                            $cliente['nome']
                                        ) ?>

                                    </option>

                                <?php endwhile; ?>

                            </select>

                        </div>


                        <div class="form-group">

                            <label for="veiculo_id">
                                Veículo
                            </label>

                            <select
                                id="veiculo_id"
                                name="veiculo_id"
                                required
                            >

                                <option value="">
                                    Selecione um veículo
                                </option>

                                <?php while ($veiculo = $veiculos->fetch_assoc()): ?>

                                    <option
                                        value="<?= $veiculo['id'] ?>"
                                    >

                                        <?= htmlspecialchars(
                                            $veiculo['marca']
                                        ) ?>

                                        <?= htmlspecialchars(
                                            $veiculo['modelo']
                                        ) ?>

                                        -
                                        <?= htmlspecialchars(
                                            $veiculo['placa']
                                        ) ?>

                                        -
                                        R$
                                        <?= number_format(
                                            $veiculo['valor_diaria'],
                                            2,
                                            ',',
                                            '.'
                                        ) ?>/dia

                                    </option>

                                <?php endwhile; ?>

                            </select>

                        </div>


                        <div class="form-group">

                            <label for="data_retirada">
                                Data de retirada
                            </label>

                            <input
                                type="date"
                                id="data_retirada"
                                name="data_retirada"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label for="data_devolucao">
                                Data de devolução
                            </label>

                            <input
                                type="date"
                                id="data_devolucao"
                                name="data_devolucao"
                                required
                            >

                        </div>

                    </div>


                    <div class="form-actions">

                        <a
                            href="index.php"
                            class="btn-secondary"
                        >
                            Cancelar
                        </a>

                        <button
                            type="submit"
                            class="btn-primary"
                        >
                            Criar locação
                        </button>

                    </div>

                </form>

            </div>

        </section>

    </main>

</body>

</html>