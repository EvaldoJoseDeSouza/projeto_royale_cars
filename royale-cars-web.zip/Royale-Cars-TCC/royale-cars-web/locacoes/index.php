<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../index.php');
    exit;
}

$sql = "
    SELECT
        locacoes.id,
        clientes.nome AS cliente,
        veiculos.marca,
        veiculos.modelo,
        veiculos.placa,
        locacoes.data_retirada,
        locacoes.data_devolucao,
        locacoes.valor_total,
        locacoes.status
    FROM locacoes

    INNER JOIN clientes
        ON locacoes.cliente_id = clientes.id

    INNER JOIN veiculos
        ON locacoes.veiculo_id = veiculos.id

    ORDER BY locacoes.id DESC
";

$locacoes = $conexao->query($sql);

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Royale Cars - Locações
    </title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >

</head>

<body>

    <aside class="sidebar">

        <div class="logo">

            <h2>
                ROYALE
                <span>CARS</span>
            </h2>

        </div>

        <nav class="menu">

            <a href="../dashboard.php">
                Dashboard
            </a>

            <a href="../veiculos/index.php">
                Frota de Veículos
            </a>

            <a href="../clientes/index.php">
                Clientes
            </a>

            <a
                href="index.php"
                class="active"
            >
                Locações
            </a>

            <a href="../financeiro/index.php">
                Financeiro
            </a>

            <a href="../configuracoes/index.php">
                Configurações
            </a>

            <a href="../logout.php">
                Sair
            </a>

        </nav>

    </aside>


    <main class="main">

        <header class="topbar">

            <h1>
                Locações
            </h1>

            <span>
                Olá,
                <?= htmlspecialchars($_SESSION['usuario_nome']) ?>
            </span>

        </header>


        <section class="content">

            <div class="page-header">

                <div>

                    <h2>
                        Locações cadastradas
                    </h2>

                    <p>
                        Gerencie as locações dos veículos.
                    </p>

                </div>

                <a
                    href="cadastrar.php"
                    class="btn-primary"
                >
                    + Nova locação
                </a>

            </div>


            <div class="table-container">

                <table>

                    <thead>

                        <tr>

                            <th>ID</th>

                            <th>Cliente</th>

                            <th>Veículo</th>

                            <th>Placa</th>

                            <th>Retirada</th>

                            <th>Devolução</th>

                            <th>Valor</th>

                            <th>Status</th>

                            <th>Ações</th>

                        </tr>

                    </thead>


                    <tbody>

                        <?php if ($locacoes && $locacoes->num_rows > 0): ?>

                            <?php while ($locacao = $locacoes->fetch_assoc()): ?>

                                <tr>

                                    <td>
                                        <?= $locacao['id'] ?>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars(
                                            $locacao['cliente']
                                        ) ?>
                                    </td>

                                    <td>

                                        <?= htmlspecialchars(
                                            $locacao['marca']
                                        ) ?>

                                        <?= htmlspecialchars(
                                            $locacao['modelo']
                                        ) ?>

                                    </td>

                                    <td>
                                        <?= htmlspecialchars(
                                            $locacao['placa']
                                        ) ?>
                                    </td>

                                    <td>
                                        <?= date(
                                            'd/m/Y',
                                            strtotime(
                                                $locacao['data_retirada']
                                            )
                                        ) ?>
                                    </td>

                                    <td>
                                        <?= date(
                                            'd/m/Y',
                                            strtotime(
                                                $locacao['data_devolucao']
                                            )
                                        ) ?>
                                    </td>

                                    <td>

                                        R$
                                        <?= number_format(
                                            $locacao['valor_total'],
                                            2,
                                            ',',
                                            '.'
                                        ) ?>

                                    </td>

                                    <td>

                                        <span class="status">

                                            <?= htmlspecialchars(
                                                $locacao['status']
                                            ) ?>

                                        </span>

                                    </td>

                                    <td>

                                        <?php if (
                                            $locacao['status'] === 'Em andamento'
                                        ): ?>

                                            <a
                                                href="finalizar.php?id=<?= $locacao['id'] ?>"
                                                class="btn-small"
                                                onclick="return confirm('Deseja finalizar esta locação?');"
                                            >
                                                Finalizar
                                            </a>

                                        <?php else: ?>

                                            <span>
                                                —
                                            </span>

                                        <?php endif; ?>

                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>

                                <td
                                    colspan="9"
                                    class="empty"
                                >

                                    Nenhuma locação cadastrada.

                                </td>

                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </section>

    </main>

</body>

</html>