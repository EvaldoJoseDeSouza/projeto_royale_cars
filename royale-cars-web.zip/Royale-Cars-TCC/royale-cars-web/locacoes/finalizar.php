<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../index.php');
    exit;
}

$id = intval($_GET['id'] ?? 0);

if ($id <= 0) {
    header('Location: index.php');
    exit;
}


/*
|--------------------------------------------------------------------------
| Buscar veículo da locação
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT veiculo_id
    FROM locacoes
    WHERE id = ?
    AND status = 'Em andamento'
";

$stmt = $conexao->prepare($sql);

$stmt->bind_param(
    'i',
    $id
);

$stmt->execute();

$resultado = $stmt->get_result();

if ($resultado->num_rows === 1) {

    $locacao = $resultado->fetch_assoc();

    $veiculo_id = $locacao['veiculo_id'];

    $stmt->close();


    /*
    |--------------------------------------------------------------------------
    | Finalizar locação
    |--------------------------------------------------------------------------
    */

    $sqlFinalizar = "
        UPDATE locacoes
        SET status = 'Finalizada'
        WHERE id = ?
    ";

    $stmtFinalizar =
        $conexao->prepare($sqlFinalizar);

    $stmtFinalizar->bind_param(
        'i',
        $id
    );

    $stmtFinalizar->execute();

    $stmtFinalizar->close();


    /*
    |--------------------------------------------------------------------------
    | Liberar veículo
    |--------------------------------------------------------------------------
    */

    $sqlVeiculo = "
        UPDATE veiculos
        SET status = 'Disponível'
        WHERE id = ?
    ";

    $stmtVeiculo =
        $conexao->prepare($sqlVeiculo);

    $stmtVeiculo->bind_param(
        'i',
        $veiculo_id
    );

    $stmtVeiculo->execute();

    $stmtVeiculo->close();

} else {

    $stmt->close();
}

header('Location: index.php');

exit;