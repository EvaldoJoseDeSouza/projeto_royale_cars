<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}


/*
|--------------------------------------------------------------------------
| FATURAMENTO TOTAL
|--------------------------------------------------------------------------
*/

$sqlFaturamento = "
    SELECT COALESCE(SUM(valor_total), 0) AS total
    FROM locacoes
    WHERE status = 'Finalizada'
";

$resultadoFaturamento = $conexao->query($sqlFaturamento);

$faturamento = $resultadoFaturamento
    ->fetch_assoc()['total'];


/*
|--------------------------------------------------------------------------
| LOCAÇÕES ATIVAS
|--------------------------------------------------------------------------
*/

$sqlLocacoesAtivas = "
    SELECT COUNT(*) AS total
    FROM locacoes
    WHERE status = 'Em andamento'
";

$resultadoLocacoesAtivas =
    $conexao->query($sqlLocacoesAtivas);

$locacoesAtivas =
    $resultadoLocacoesAtivas
        ->fetch_assoc()['total'];


/*
|--------------------------------------------------------------------------
| CLIENTES ATIVOS
|--------------------------------------------------------------------------
*/

$sqlClientes = "
    SELECT COUNT(*) AS total
    FROM clientes
    WHERE arquivado = FALSE
";

$resultadoClientes =
    $conexao->query($sqlClientes);

$totalClientes =
    $resultadoClientes
        ->fetch_assoc()['total'];


/*
|--------------------------------------------------------------------------
| TOTAL DE VEÍCULOS
|--------------------------------------------------------------------------
*/

$sqlTotalVeiculos = "
    SELECT COUNT(*) AS total
    FROM veiculos
    WHERE arquivado = FALSE
";

$resultadoTotalVeiculos =
    $conexao->query($sqlTotalVeiculos);

$totalVeiculos =
    $resultadoTotalVeiculos
        ->fetch_assoc()['total'];


/*
|--------------------------------------------------------------------------
| VEÍCULOS DISPONÍVEIS
|--------------------------------------------------------------------------
*/

$sqlDisponiveis = "
    SELECT COUNT(*) AS total
    FROM veiculos
    WHERE status = 'Disponível'
    AND arquivado = FALSE
";

$resultadoDisponiveis =
    $conexao->query($sqlDisponiveis);

$veiculosDisponiveis =
    $resultadoDisponiveis
        ->fetch_assoc()['total'];


/*
|--------------------------------------------------------------------------
| VEÍCULOS ALUGADOS
|--------------------------------------------------------------------------
*/

$sqlAlugados = "
    SELECT COUNT(*) AS total
    FROM veiculos
    WHERE status = 'Alugado'
    AND arquivado = FALSE
";

$resultadoAlugados =
    $conexao->query($sqlAlugados);

$veiculosAlugados =
    $resultadoAlugados
        ->fetch_assoc()['total'];


/*
|--------------------------------------------------------------------------
| ÚLTIMAS LOCAÇÕES
|--------------------------------------------------------------------------
*/

$sqlUltimasLocacoes = "
    SELECT
        locacoes.id,
        clientes.nome AS cliente,
        veiculos.marca,
        veiculos.modelo,
        veiculos.placa,
        locacoes.valor_total,
        locacoes.status,
        locacoes.data_retirada,
        locacoes.data_devolucao

    FROM locacoes

    INNER JOIN clientes
        ON locacoes.cliente_id = clientes.id

    INNER JOIN veiculos
        ON locacoes.veiculo_id = veiculos.id

    ORDER BY locacoes.id DESC

    LIMIT 5
";

$ultimasLocacoes =
    $conexao->query($sqlUltimasLocacoes);

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Dashboard - Royale Cars
    </title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

    <link
        rel="stylesheet"
        href="css/dashboard.css"
    >

</head>

<body>

    <aside class="sidebar">

        <div class="logo">

            <h2>
                ROYALE
                <span>CARS</span>
            </h2>

            <p class="logo-subtitle">
                Sistema de Gestão
            </p>

        </div>

        <nav class="menu">

            <a
                href="dashboard.php"
                class="active"
            >
                Dashboard
            </a>

            <a href="veiculos/index.php">
                Frota de Veículos
            </a>

            <a href="clientes/index.php">
                Clientes
            </a>

            <a href="locacoes/index.php">
                Locações
            </a>

            <a href="financeiro/index.php">
                Financeiro
            </a>

            <a href="configuracoes/index.php">
                Configurações
            </a>

            <a href="logout.php">
                Sair
            </a>

        </nav>

    </aside>


    <main class="main">

        <header class="topbar">

            <div>

                <h1>
                    Dashboard
                </h1>

                <p class="topbar-subtitle">
                    Visão geral da Royale Cars
                </p>

            </div>

            <div class="usuario-topo">

                <div class="usuario-avatar">

                    <?= strtoupper(
                        substr(
                            $_SESSION['usuario_nome'],
                            0,
                            1
                        )
                    ) ?>

                </div>

                <div>

                    <strong>
                        <?= htmlspecialchars(
                            $_SESSION['usuario_nome']
                        ) ?>
                    </strong>

                    <small>
                        Administrador
                    </small>

                </div>

            </div>

        </header>


        <section class="content">

            <div class="dashboard-header">

                <div>

                    <h2>
                        Bem-vindo,
                        <?= htmlspecialchars(
                            $_SESSION['usuario_nome']
                        ) ?>!
                    </h2>

                    <p>
                        Acompanhe os principais indicadores
                        do sistema.
                    </p>

                </div>

            </div>


            <!-- CARDS PRINCIPAIS -->

            <div class="dashboard-cards">

                <div class="dashboard-card">

                    <div class="dashboard-card-icon">
                        $
                    </div>

                    <div>

                        <span>
                            Faturamento total
                        </span>

                        <strong>

                            R$
                            <?= number_format(
                                $faturamento,
                                2,
                                ',',
                                '.'
                            ) ?>

                        </strong>

                    </div>

                </div>


                <div class="dashboard-card">

                    <div class="dashboard-card-icon">
                        L
                    </div>

                    <div>

                        <span>
                            Locações ativas
                        </span>

                        <strong>
                            <?= $locacoesAtivas ?>
                        </strong>

                    </div>

                </div>


                <div class="dashboard-card">

                    <div class="dashboard-card-icon">
                        C
                    </div>

                    <div>

                        <span>
                            Clientes ativos
                        </span>

                        <strong>
                            <?= $totalClientes ?>
                        </strong>

                    </div>

                </div>


                <div class="dashboard-card">

                    <div class="dashboard-card-icon">
                        V
                    </div>

                    <div>

                        <span>
                            Total de veículos
                        </span>

                        <strong>
                            <?= $totalVeiculos ?>
                        </strong>

                    </div>

                </div>

            </div>


            <!-- CARDS DE FROTA -->

            <div class="frota-resumo">

                <div class="resumo-card">

                    <div>

                        <span>
                            Veículos disponíveis
                        </span>

                        <strong>
                            <?= $veiculosDisponiveis ?>
                        </strong>

                    </div>

                    <div class="bolinha-status disponivel"></div>

                </div>


                <div class="resumo-card">

                    <div>

                        <span>
                            Veículos alugados
                        </span>

                        <strong>
                            <?= $veiculosAlugados ?>
                        </strong>

                    </div>

                    <div class="bolinha-status alugado"></div>

                </div>

            </div>


            <!-- ÚLTIMAS LOCAÇÕES -->

            <div class="dashboard-section">

                <div class="section-header">

                    <div>

                        <h2>
                            Últimas locações
                        </h2>

                        <p>
                            Movimentações mais recentes do sistema.
                        </p>

                    </div>

                    <a
                        href="locacoes/index.php"
                        class="btn-primary"
                    >
                        Ver todas
                    </a>

                </div>


                <div class="table-container">

                    <table>

                        <thead>

                            <tr>

                                <th>ID</th>

                                <th>Cliente</th>

                                <th>Veículo</th>

                                <th>Placa</th>

                                <th>Período</th>

                                <th>Valor</th>

                                <th>Status</th>

                            </tr>

                        </thead>


                        <tbody>

                            <?php if (
                                $ultimasLocacoes &&
                                $ultimasLocacoes->num_rows > 0
                            ): ?>

                                <?php while (
                                    $locacao =
                                    $ultimasLocacoes->fetch_assoc()
                                ): ?>

                                    <tr>

                                        <td>
                                            #<?= $locacao['id'] ?>
                                        </td>

                                        <td>

                                            <?= htmlspecialchars(
                                                $locacao['cliente']
                                            ) ?>

                                        </td>

                                        <td>

                                            <?= htmlspecialchars(
                                                $locacao['marca']
                                            ) ?>

                                            <?= htmlspecialchars(
                                                $locacao['modelo']
                                            ) ?>

                                        </td>

                                        <td>

                                            <?= htmlspecialchars(
                                                $locacao['placa']
                                            ) ?>

                                        </td>

                                        <td>

                                            <?= date(
                                                'd/m/Y',
                                                strtotime(
                                                    $locacao[
                                                        'data_retirada'
                                                    ]
                                                )
                                            ) ?>

                                            até

                                            <?= date(
                                                'd/m/Y',
                                                strtotime(
                                                    $locacao[
                                                        'data_devolucao'
                                                    ]
                                                )
                                            ) ?>

                                        </td>

                                        <td>

                                            R$
                                            <?= number_format(
                                                $locacao[
                                                    'valor_total'
                                                ],
                                                2,
                                                ',',
                                                '.'
                                            ) ?>

                                        </td>

                                        <td>

                                            <span class="status">

                                                <?= htmlspecialchars(
                                                    $locacao['status']
                                                ) ?>

                                            </span>

                                        </td>

                                    </tr>

                                <?php endwhile; ?>

                            <?php else: ?>

                                <tr>

                                    <td
                                        colspan="7"
                                        class="empty"
                                    >

                                        Nenhuma locação encontrada.

                                    </td>

                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </section>

    </main>

</body>

</html>