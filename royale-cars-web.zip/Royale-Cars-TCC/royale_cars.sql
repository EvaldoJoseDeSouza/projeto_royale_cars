-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 01/09/2026 às 03:59
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `royale_cars`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `telefone` varchar(30) DEFAULT NULL,
  `arquivado` tinyint(1) DEFAULT 0,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `clientes`
--

INSERT INTO `clientes` (`id`, `nome`, `cpf`, `email`, `telefone`, `arquivado`, `criado_em`) VALUES
(1, 'João da Silva', '123.456.789-00', 'joao@gmail.com', '(19) 99999-9999', 0, '2026-09-01 00:25:04'),
(2, 'Evaldo josé', '13252287624', 'evaldo@gmail.com', '1940028922', 0, '2026-09-01 01:19:59'),
(3, 'Caio andrade', '145.874.963.10', 'andrade@gmail.com', '19489568439', 0, '2026-09-01 01:21:06');

-- --------------------------------------------------------

--
-- Estrutura para tabela `locacoes`
--

CREATE TABLE `locacoes` (
  `id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `veiculo_id` int(11) NOT NULL,
  `data_retirada` date NOT NULL,
  `data_devolucao` date NOT NULL,
  `valor_total` decimal(10,2) NOT NULL,
  `status` enum('Em andamento','Finalizada') DEFAULT 'Em andamento',
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `locacoes`
--

INSERT INTO `locacoes` (`id`, `cliente_id`, `veiculo_id`, `data_retirada`, `data_devolucao`, `valor_total`, `status`, `criado_em`) VALUES
(1, 1, 3, '2026-09-01', '2026-09-04', 1500.00, 'Finalizada', '2026-09-01 00:31:45'),
(2, 3, 7, '2026-09-09', '2026-09-15', 2700.00, 'Finalizada', '2026-09-01 01:29:55'),
(3, 2, 11, '2026-09-12', '2026-09-20', 20000.00, 'Em andamento', '2026-09-01 01:50:10');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `criado_em`) VALUES
(1, 'Gabriel S', 'gabriel@gmail.com', '$2y$10$8Qr/oNo0oxJ5hFQC7TrAr.Ri0JDoL3cSdt.qADADmgL4WtJ1fjXJ2', '2026-08-31 22:38:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `veiculos`
--

CREATE TABLE `veiculos` (
  `id` int(11) NOT NULL,
  `marca` varchar(100) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `ano` int(11) NOT NULL,
  `placa` varchar(20) NOT NULL,
  `valor_diaria` decimal(10,2) NOT NULL,
  `status` enum('Disponível','Alugado','Em Manutenção') DEFAULT 'Disponível',
  `arquivado` tinyint(1) DEFAULT 0,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `veiculos`
--

INSERT INTO `veiculos` (`id`, `marca`, `modelo`, `ano`, `placa`, `valor_diaria`, `status`, `arquivado`, `criado_em`) VALUES
(1, 'Toyota', 'Corolla', 2025, 'FE1G33', 350.00, 'Disponível', 1, '2026-08-31 23:17:45'),
(2, 'BMW', '320i', 2024, 'DEF2E34', 500.00, 'Alugado', 1, '2026-08-31 23:30:18'),
(3, 'BMW', 'M3', 2026, 'ABC1D23', 500.00, 'Disponível', 0, '2026-08-31 23:32:33'),
(4, 'Audi', 'A5 Sportback', 2024, 'AUD5E67', 700.00, 'Disponível', 0, '2026-09-01 01:24:20'),
(7, 'Volkswagen', 'Jetta GLI', 2023, 'GTR3R35', 450.00, 'Disponível', 0, '2026-09-01 01:29:05'),
(10, 'Porsche', '911 Carrera', 2024, 'POR9A25', 1800.00, 'Disponível', 0, '2026-09-01 01:46:32'),
(11, 'Mercedes-Benz', 'C63 AMG', 2026, 'MER6B24', 2500.00, 'Alugado', 0, '2026-09-01 01:47:29');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cpf` (`cpf`);

--
-- Índices de tabela `locacoes`
--
ALTER TABLE `locacoes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`),
  ADD KEY `veiculo_id` (`veiculo_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices de tabela `veiculos`
--
ALTER TABLE `veiculos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `placa` (`placa`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `locacoes`
--
ALTER TABLE `locacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `veiculos`
--
ALTER TABLE `veiculos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `locacoes`
--
ALTER TABLE `locacoes`
  ADD CONSTRAINT `locacoes_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  ADD CONSTRAINT `locacoes_ibfk_2` FOREIGN KEY (`veiculo_id`) REFERENCES `veiculos` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
