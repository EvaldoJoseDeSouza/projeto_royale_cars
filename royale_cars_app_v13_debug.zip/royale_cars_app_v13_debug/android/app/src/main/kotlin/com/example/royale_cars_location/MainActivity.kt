package com.example.royale_cars_location

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
