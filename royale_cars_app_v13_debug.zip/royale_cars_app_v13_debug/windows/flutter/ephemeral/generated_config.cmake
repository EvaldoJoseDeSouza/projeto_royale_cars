# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\develop\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\Usuário\\OneDrive\\Documentos\\royale_cars_app_tania_v2" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\develop\\flutter"
  "PROJECT_DIR=C:\\Users\\Usuário\\OneDrive\\Documentos\\royale_cars_app_tania_v2"
  "FLUTTER_ROOT=C:\\develop\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\Usuário\\OneDrive\\Documentos\\royale_cars_app_tania_v2\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\Usuário\\OneDrive\\Documentos\\royale_cars_app_tania_v2"
  "FLUTTER_TARGET=C:\\Users\\Usuário\\OneDrive\\Documentos\\royale_cars_app_tania_v2\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDQuMQ==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049OTI0MTM0YTQ0Yw==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049YzQxNmFjZmViOA==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMi4x"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\Usuário\\OneDrive\\Documentos\\royale_cars_app_tania_v2\\.dart_tool\\package_config.json"
)
