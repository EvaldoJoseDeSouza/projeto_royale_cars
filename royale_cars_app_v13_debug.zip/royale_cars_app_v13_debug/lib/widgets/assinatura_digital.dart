import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:signature/signature.dart';
import '../theme/colors.dart';

/// Tela de assinatura digital do cliente — usada na confirmação do
/// contrato de locação. Devolve a assinatura como PNG em base64
/// (mesmo formato salvo na coluna `assinatura_base64` da locação).
///
/// 🌟 Esta é a funcionalidade de "assinatura de contratos" apontada
/// como faltante na avaliação da banca.
class TelaAssinaturaDigital extends StatefulWidget {
  final String tituloContrato;

  const TelaAssinaturaDigital({super.key, required this.tituloContrato});

  @override
  State<TelaAssinaturaDigital> createState() => _TelaAssinaturaDigitalState();
}

class _TelaAssinaturaDigitalState extends State<TelaAssinaturaDigital> {
  final SignatureController _controlador = SignatureController(
    penStrokeWidth: 3,
    penColor: RoyaleColors.azulMarinho,
    exportBackgroundColor: Colors.white,
  );

  @override
  void dispose() {
    _controlador.dispose();
    super.dispose();
  }

  Future<void> _confirmar() async {
    if (_controlador.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: RoyaleColors.statusAlugado,
          content: Text('Peça para o cliente assinar antes de confirmar.'),
        ),
      );
      return;
    }

    final Uint8List? bytesPng = await _controlador.toPngBytes();
    if (bytesPng == null) return;

    final base64Assinatura = base64Encode(bytesPng);
    if (mounted) Navigator.pop(context, base64Assinatura);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.tituloContrato)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text(
              'Peça para o cliente assinar no espaço abaixo para confirmar o contrato de locação.',
              textAlign: TextAlign.center,
              style: TextStyle(color: RoyaleColors.textoMuted),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: RoyaleColors.bordaClara, width: 2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Signature(
                  controller: _controlador,
                  backgroundColor: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => _controlador.clear(),
                    child: const Text('Limpar'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _confirmar,
                    child: const Text('Confirmar Assinatura'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
